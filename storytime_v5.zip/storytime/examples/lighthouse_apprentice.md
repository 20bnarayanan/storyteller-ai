# The Keeper's Apprentice and the Long Storm

Gannet Rock had been Wren Halloway's home for a whole season, and in all that time she had carried more oil cans than she could count and polished more brass than she cared to remember. She had never once been trusted with the lamp itself. Old Tobiah Marsh, the head keeper, kept the great lens to himself the way a miser keeps his coins, and every evening he repeated the same rule as if it were a prayer. The light never goes dark. The keeper never leaves it unattended.

"You will have your turn, Halloway," he had told her that morning, not unkindly, while he checked the weight cords with his thick, careful fingers. "Patience is a keeper's first tool."

Wren had nodded, but patience felt like a bucket with a hole in it.

By dusk the wind had turned mean. It came off the sea in long, shoving gusts that rattled the iron shutters and sent **brine** hissing against the glass like handfuls of thrown gravel. Wren tasted salt on her lips every time she opened her mouth. Pim, the stubborn gull who roosted on the gallery rail, had retreated into the lantern housing and was muttering over a stolen brass button.

Then the tower shuddered. A gust struck with such force that the whole stair seemed to groan, and from somewhere below came a hollow cry and a sickening thump.

Wren ran. She found Tobiah on the landing, halfway down the spiral, his face grey and his left ankle bent at a wrong angle. He had slipped on the wet granite where the spray had crept through the gap under the door.

"Go back up," he gasped. "Keep the lamp. Don't you dare leave it."

"I can't carry you," she said.

"No. You can't. So you'll keep the light." His jaw tightened against the pain. "Go on."

She climbed. One hundred and twelve steps, her breath sawing in her chest, until the great lens loomed above her like a glittering cathedral. The clockwork weight had dropped low. The flame was already leaning and sputtering.

Wren did not panic. She wound the clockwork with slow, steady turns of the crank, counting each one aloud so her voice would stop her hands from trembling. She trimmed the wick with the small brass shears. The flame steadied, then sank again.

*Keep the light steady, keep your hands steady, and keep faith.*

Through the rain-streaked glass she saw it: a small dark shape bobbing near the reef, a fishing boat with its lantern swinging wildly. It was drifting toward the rocks, and it could not see the channel.

The oil reserve sat in the storeroom beneath the landing, the only place with enough to last the night. To reach it she would have to leave the lamp, descend past her injured mentor, and climb back with a full can, all while the flame guttered in the dark. Her heart hammered. The rule rang in her ears. Never leave the lamp.

Wren stood very still and made herself think. Her **vigil** had already lasted two hours, and her eyes burned, but she kept watching the flame and the boat together. Leaving the lamp was one way forward. There had to be another.

Then she remembered the speaking-tube, and the signal lamp fixed beside it, and the faces she had seen on the cliff at harbor-time: Mrs. Oduya, who kept her own vigil on the village cliff with a lantern and a keen, unblinking eye.

Wren moved with **deliberate** care. She lifted the brass shutter and began flashing the long and short code that every fisherman on the coast understood. Danger on the reef. Boat drifting. Send help to the channel. Oil low at the rock.

Across the black water, a light answered at once. Mrs. Oduya was reading her.

Next she bent to the speaking-tube. "Tobiah," she called down. "I'm not leaving the gallery. I'm going to haul the oil up on the rope. Tell me if I've got it wrong."

A long pause, then his hoarse reply came up the pipe. "You've got it right, lass. Do it."

She lowered the empty bucket on the pulley rope, watched it drop into the dark, and hauled it back full. Her arms burned. Her palms stung. The flame rose, bright and steady, and the boat's lantern swung toward it.

The storm raged on, but Wren kept the light burning until the first grey light crept over the sea. The fishing boats came home one by one through the channel, their lanterns bobbing safely past the rocks.

*Keep the light steady, and keep faith.*

When the sun finally lifted, two village men carried Tobiah up the stairs on a stretcher, his ankle bound tight in linen. He looked at her for a long moment, then at the lens, glowing pale in the dawn.

"A keeper's first duty," he said slowly, "is to be honest about what she can do. And to ask for help when she can't. You did both."

Wren felt something warm settle in her chest, quieter than pride and deeper, like a stone that had found its place. She had kept faith with the light, and with the people who depended on it.

*Keep the light, and keep faith.*

Wren smiled and leaned against the cool brass of the lens. Her eyelids grew heavy. The sea rolled gently against the stone.

She dreamed of boats coming home across quiet water, and of a little light that never went dark.

*Keep faith.*

---

**Words we met tonight ✨**

- **Vigil:** a long, watchful staying-awake, kept on purpose to protect something
- **Deliberate:** done slowly and on purpose, after careful thought
- **Brine:** salty water, especially the spray and sea-air that clings to everything near the ocean

**Ask your little storyteller:** "Wren keeps a long vigil through the storm, so what do you think it felt like for her to stay awake all night, and when have you ever kept watch over something important to you?"
