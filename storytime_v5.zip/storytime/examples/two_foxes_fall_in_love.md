# The Two Foxes of Hollow Ridge

Rusty was a young red fox with a bushy tail and a curious nose. One evening, as the sun slipped behind the hills, he played in the birch grove of Hollow Ridge. The birch trees were tall and pale, and their leaves whispered secrets to one another. Rusty loved puzzles more than anything, so he kept his ears up and his eyes open.

Then he heard it. A soft, silver ring floated down from high in the trees, clear as a raindrop on a puddle.

"Who's up there?" Rusty called, tipping his head back.

The bell only rang once more, then fell silent. Rusty sat very still, his tail twitching with wonder.

*Ring the silver bell, and let your true heart speak out loud.*

The wind hummed a little song through the birches, and Rusty listened to every word.

The next morning, Rusty hurried to his favorite branch, the one that bent low over the ferns. There, tied with a ribbon of blue thread, hung a tiny silver bell. It was shaped like a teardrop and shone in the sunlight.

Old Badger Thistlewick shuffled up beside him, leaning on his walking stick. He peered at the bell over his spectacles.

"Hmm," said the badger. "I know every path and every branch in this wood. That bell belongs to no one I know."

"Then who rang it?" asked Rusty, his heart thumping.

"Ah," said Thistlewick with a twinkle. "That is a question for a fox who keeps his eyes open."

That evening, Rusty did not play. He waited under the birches, watching for clues. He found muddy paw prints leading into the ferns. He found a trail of dropped blackberries, one after another, like breadcrumbs. Each time he followed the trail, a bell rang just out of sight. Rusty would **scamper** through the ferns, leaves tickling his nose, but each time the ringer slipped away like smoke.

"Almost!" he panted. "Almost, almost!"

His little sister Pip was never far behind him. "You're going to fall in a puddle again," she chirped. "I can see your footprints from here, and they're all wobbly!"

"They are not wobbly!" Rusty protested, and promptly tripped over a root.

At last, one night, the trail led him to the stream. The water sparkled like spilled stars, and a **glimmer** of soft light danced across its surface. There, on a flat stone, sat a silver-tipped fox with bright, clever eyes.

"You found me," said Juniper, grinning. "I thought you never would."

Rusty opened his mouth to speak, but his words tangled like wet string. He scratched his ear and stared hard at his paws. He felt too **bashful** to say hello properly.

"Um. Hi. Your bells. They're... nice," he stammered. "Really, really nice. Um. Also, your ribbon is blue. Blue is a nice color. For ribbons."

Juniper laughed, a sound like the stream over pebbles. "Thank you, Rusty. You're very good at talking about ribbons."

Rusty groaned, but he was smiling too.

*Ring the silver bell, and let your true heart speak.*

Days passed, and the bells rang every evening. Then one night, no bell rang at all. Rusty searched the birch grove and found Juniper sitting alone by the stream, her head drooping.

"My bell is gone," she whispered. "It was my favorite. I think I lost it somewhere in the ferns, and I can't find it anywhere."

Rusty's tail drooped too. He wanted to help, but a small voice in his head whispered, *Stay quiet. You'll only make another silly joke.*

Then Rusty remembered the stream, where every word must be true. He took a deep breath and let the truth tumble out.

"Juniper, I have liked your bells since the very first one," he said, his voice wobbling. "And I like your company, too. You make the whole wood feel warmer. I wanted you to know that."

Juniper's ears lifted. She looked at him for a long moment. "Truly?"

"Truly," said Rusty, and his heart pounded like a drum. "And I'll help you find your bell. Right now."

They searched together through the ferns, pushing aside leaves and peering under mossy stones. Rusty's nose twitched at every scent, and Juniper's sharp eyes caught every glint. At last, tangled among the fronds, they spotted a small silver shine.

Juniper gasped. Rusty pulled it free with his teeth, gently, and placed it in her paws.

Together, they gave the bell a gentle shake. Ring. The sound was soft and sweet.

Then Juniper rang her bell, and Rusty rang his, and the two rings chimed together like friends laughing.

*Ring the silver bell, and let your heart speak.*

From that night on, Rusty and Juniper left bells for each other every evening, tied to the birch branches with ribbons of blue thread. Old Badger Thistlewick nodded wisely each time one appeared.

Pip sniffed the air one evening and declared, with great seriousness, "The whole wood smells like happiness now."

Rusty laughed softly, and Juniper's tail brushed against his.

The stream sparkled gently in the moonlight. The birches whispered goodnight. Somewhere high above, a silver bell chimed once more, and then the wood grew still.

*Let your heart speak.*

---

**Words we met tonight ✨**

- **Scamper:** to run or move quickly with small, light steps, like a playful animal
- **Bashful:** shy and a little embarrassed, especially around someone you like
- **Glimmer:** a faint, soft, flickering light

**Ask your little storyteller:** "Rusty felt bashful when he first met Juniper. Can you remember a time you felt bashful, and what helped you feel brave again?"
