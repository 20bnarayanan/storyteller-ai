# Pip the Penguin and the Midnight Parade

Pip the penguin **waddled** across the snowy ice shelf. Side to side, side to side, like a little wind-up toy. The night was cold and clear. Above him, a sky full of soft silver stars twinkled and winked.

Far away, the parade drums began. Thump, thump, thump. Pip's flippers tingled. He wanted to march. He wanted to feel the snow swish under his feet.

*Little penguin, step by step, step by step, all the way home.*

The wind hummed a little song, and Pip heard every word.

Then Bo the Bold came rolling past, round and cheerful, with a big grin on his beak. "Come join us, Pip!" Bo called. "The parade is starting!"

Pip's tummy went **wobbly**, like a bowl of jelly that would not sit still. He thought of all the eyes that would be watching him. His feet stopped moving. Before he knew it, he ducked behind a big blue ice rock.

Mama Penguin came waddling over. She sat down beside the rock, close and warm. She began to hum a soft, slow tune. Hmmmm, hmmmm. The tune floated over the snow like a quiet blanket.

"Feeling wobbly?" Mama asked gently.

Pip nodded. "Everyone will look at me," he whispered.

Old Owl Hoo blinked from his perch on a nearby ice post. His big round eyes glowed in the starlight. "Small steps are still steps, little one," said Owl Hoo. "Even a tiny step takes you somewhere."

Pip thought about that. Then he peeked out from behind the rock. The ice **glistened** under the stars, shining like a sea of tiny mirrors. The parade was getting closer. Swish, swish, went the marchers' feet.

Pip took one wobbly step. Then he hid again.

*Little penguin, step by step, step by step.*

Mama Penguin hummed on, and the wind sang along, and Pip listened to the lovely swish of the parade.

Pip took a deep breath. In. Out. He felt his tummy wobble, but he kept breathing. He placed one flipper on the cold, soft snow. Then he placed the other.

He stepped out from behind the big blue rock. He waddled into the line of marchers, side to side, side to side.

Bo the Bold clapped his flippers. "Hooray, Pip!" he cheered. Nobody scolded him, and nobody laughed. The penguins just smiled and kept on marching.

*Little penguin, step by step.*

The wind hummed, and Pip felt its soft song in his chest.

Pip marched slowly beside his friends. Swish, swish, went his feet on the frozen bay. The stars blinked down on the parade like tiny lanterns. The drums went thump, thump, softer now, like a heartbeat growing sleepy.

Pip's tummy felt warm and calm again. The wobbles had settled, like jelly that had finally stopped shaking. He was glad he had taken that first small step.

Mama Penguin hummed beside him. Owl Hoo nodded from his post, his eyes slowly closing.

The parade wound its way across the ice. The snow glistened. The night was gentle and still. Pip yawned a small, happy yawn.

*Step by step.*

---

**Words we met tonight ✨**

- **Waddle:** to walk with short, rocking steps, side to side
- **Wobbly:** shaky and unsteady, like jelly or a loose tooth
- **Glisten:** to shine softly, like wet snow or ice in the moonlight

**Ask your little storyteller:** "Pip's tummy felt wobbly, like jelly. Where do you feel wobbly when you are nervous, and what helps your wobbly feeling settle down?"
