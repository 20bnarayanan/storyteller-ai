# Barnaby Bear and the Missing Blanket

Barnaby Bear yawned a big, wide yawn. "Time for bed," he said softly. The den was snug and warm under the big pine tree. Moonlight peeked through the leaves, and the wind went swish, swish, swish outside.

Barnaby reached for his soft blue blanket. His paws felt around the pillow, but they felt only the pillow and not the edge of his bed. The blanket was not there.

"Oh no," said Barnaby. He looked under his pillow. Nothing. He looked behind the big log. Nothing at all.

*Hush now, soft blanket, sleepy little bear, sleep.*

Barnaby sang a little song to himself: "Hush now, soft blanket, sleepy little bear, sleep." His voice was small and wobbly.

Pip the squirrel came hopping down from the branches. His bushy tail went flick, flick, flick. "I will help you look," Pip said. "Two friends search better than one."

So they searched. First they peeked inside the **hollow** tree. They knocked on the wood. Knock, knock. The sound was hollow and empty. Only leaves and acorns were inside.

Next they searched the cozy pile of leaves by the stream. Barnaby dug with his paws. No blue blanket. Only a twig and a fuzzy caterpillar.

Barnaby's tummy went **wobble**, wobble, wobble. He did not like that feeling at all.

Up in the high branch, Owl blinked his big round eyes. "I have not seen it," Owl hooted softly. "But I can see the whole forest tonight."

Barnaby sat down on the soft grass. He stopped. He took a slow, deep breath. His tummy began to feel a little less wobbly.

"Thank you, Pip," said Barnaby. "I think I can be brave tonight. I will sleep without my blanket, just this once."

He padded back to his den. He lay down and **tucked** his paws under his chin. He hugged his own round, warm belly. It felt cozy too.

*Hush now, soft blanket, sleepy bear, sleep.*

Barnaby hummed his little song once more: "Hush now, soft blanket, sleepy bear, sleep." The wind swished softly through the pine.

Then Barnaby remembered. Before the search, he had tossed his blanket onto his own bed. He reached over, and his paws touched something soft and blue, right where he had left it all along!

Barnaby giggled a sleepy giggle. "It was here the whole time!"

He pulled the blanket up snug. He tucked it under his chin, just the way he liked it. His tummy felt calm and warm. Mama Bear smiled from the doorway and gave him a kiss on the top of his head.

*Hush now, soft blanket, sleep.*

The moon glowed softly over the pine tree. Owl blinked and settled into his branch. Pip curled up in his leafy nest.

Barnaby's eyes grew heavy. His breathing slowed.

Mama Bear whispered, "Goodnight, little bear."

Barnaby mumbled one last sleepy word.

*Hush now, sleep.*

---

**Words we met tonight ✨**

- **Tuck:** to fold or push something snugly into a cozy place, like pulling a blanket up under your chin
- **Wobble:** to shake or move unsteadily from side to side, like jelly or a wobbly tummy
- **Hollow:** empty inside, like the hole in the middle of a big old tree

**Ask your little storyteller:** "Barnaby's tummy went wobble, wobble, wobble when he was worried. Can you show me how your tummy feels when you are a little worried, and what helps it feel better?"
