# The Moon in Mabel's Pond

Mabel carried her flashlight across the wet grass, her muddy boots squeaking with every step. She was searching for her frog-spotting notebook, which she had lost somewhere near the tall sunflowers. Crickets sang loudly from every corner of the garden. Then she noticed a silver glow rippling in the round stone pond.

She knelt beside the water and peered in. There, floating among the lily pads, was the full moon! It **shimmered** on the surface like a silver coin, wobbling every time a ripple passed. Mabel gasped and pressed her nose close to the edge.

"Oh my," she whispered. "The moon is in the pond."

A small green voice croaked from under a lily pad. "It fell in this afternoon, when the wind was blowing so hard." A young frog poked his head out. He had big, worried eyes and a very shy smile. "My name is Pim. I live here. I've been trying to help, but I'm too small."

"Hello, Pim. I'm Mabel," she said. "Why is the moon all **tangled** up?"

Pim looked closer. "The moon got caught in the water lily roots. They wrapped around it like a ball of string. It cannot rise on its own."

Mabel frowned at the knot of roots. Her heart beat fast. "Then I'll pull it out right now!" She grabbed the garden rake from the grass and hooked it toward the moon. The rake clacked against the stones, and the moon wobbled wildly. Its light splashed over the edges of the pond.

"Stop, stop!" squeaked Pim. "Too rough! You'll make it dim all night!"

Mabel dropped the rake and sat back on her heels. She felt flustered and a little silly. Maybe grabbing was not the answer.

Just then, Grandpa Ike came strolling out in his slippers, carrying a cup of cocoa. He chuckled at the mess of lily pads. "Ah, I see you've found our moon," he said. "Old stories say the moon only rises when someone gently unties its roots. It cannot lift itself, sweetheart. It needs a careful hand."

Next door, Mrs. Oduya leaned over the fence in her bathrobe. "Nonsense," she called. "That is just a reflection. The real moon is up in the sky where it belongs!"

Mabel stood up and looked at the dark sky. It was true that the sky above the garden looked dim. "Pim, can we prove it?" she asked.

Pim nodded bravely. Together, they draped Grandpa Ike's old blue cloth over the pond. The water went dark, and the sky above stayed dim, too.

"Hmm," said Mrs. Oduya, peeking over the fence. She did not say anything else.

Mabel knelt at the water's edge again. Now the sky was growing darker by the minute. Her hands itched to hurry. But she remembered how the moon had wobbled, and she took a deep breath.

"We need to be slow," she told Pim. "Like we are untying a knot."

Pim swam to the lily pads and held them steady with his tiny feet. Mabel reached into the cool water and found the first root. She pulled gently, one twist at a time. The root loosened. Then she found the next one.

*Gently, roots, let the moon go free and rise.*

Mabel sang softly as she worked, and the crickets seemed to hush to listen. She felt **patient**, even though her fingers wanted to rush. One root slid free, then another. Pim's eyes shone with pride.

*Gently, roots, let the moon go free.*

At last, the final root slipped loose. The moon gave a soft, happy shimmer and rose out of the water. It drifted up past the sunflowers, sparkling and trembling, until it hung high in the sky, bright and round. The whole garden glowed silver.

*Gently, let the moon go free.*

Mabel and Pim waved goodnight to the moon. Next door, Mrs. Oduya looked up at the sky for a long moment, then smiled a small, surprised smile.

"Goodnight, moon," Mabel whispered, yawning. Pim croaked a sleepy goodnight too.

*Let it go.*

---

**Words we met tonight ✨**

- **Tangle:** to get twisted up together in a messy knot, like yarn or roots
- **Patient:** able to stay calm and wait without rushing, even when something takes a long time
- **Shimmer:** to shine with a soft, trembling light that seems to ripple

**Ask your little storyteller:** "Mabel decided to be patient instead of grabbing the moon. Can you think of a time when going slowly and carefully helped you, and how did it feel?"
